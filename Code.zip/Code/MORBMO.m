function REP = MORBMO(params, MultiObj)

    % Parameter initialization
    Np = params.Np;
    Nr = params.Nr;
    maxgen = params.maxgen;
    ngrid = params.ngrid;
    fun = MultiObj.fun;
    nVar = MultiObj.nVar;
    var_min = MultiObj.var_min(:);
    var_max = MultiObj.var_max(:);
    name = MultiObj.name;
    Nf = MultiObj.numOfObj;
    
    % Initialize the relevant parameters
    fit = inf(Np, Nf);
    
    % Population initialization
    X = initialization(Np, nVar, var_max, var_min);
    for i = 1:Np
        fit(i, :) = fun(X(i, :));
    end

    % Initialize the archive
    REP = initializeRepository(X, fit, ngrid);

    % Main loop
    t = 1;
    while t <= maxgen
        
        % Exploration stage
        CF = (1 - t / maxgen)^(2 * t / maxgen);
        for i = 1:Np
            num_to_select1 = randi([2, 5]);
            selected_indices1 = randperm(Np, num_to_select1);
            X1 = X(selected_indices1, :);
            X1 = mean(X1);

            num_to_select2 = randi([10, Np]);
            selected_indices2 = randperm(Np, num_to_select2);
            X2 = X(selected_indices2, :);
            X2 = mean(X2);

            A = randperm(Np);
            R1 = A(1);
            if rand < 0.5
                X(i, :) = X(i, :) + (X1 - X(R1, :)) .* rand;
            else
                X(i, :) = X(i, :) + (X2 - X(R1, :)) .* rand;
            end
        end

        % Boundary processing
        X = boundaryCheck(X, var_min, var_max);

        % Update fitness
        for i = 1:Np
            fit(i, :) = fun(X(i, :));
        end

        % Archive update
        REP = updateRepository(REP, X, fit, ngrid, Nr);

        % Exploitation stage
        for i = 1:Np
            num_to_select1 = randi([2, 5]);
            selected_indices1 = randperm(Np, num_to_select1);
            X1 = X(selected_indices1, :);
            X1 = mean(X1);

            num_to_select2 = randi([10, Np]);
            selected_indices2 = randperm(Np, num_to_select2);
            X2 = X(selected_indices2, :);
            X2 = mean(X2);

            % Select the leader using the roulette method
            leader_idx = selectLeader(REP);
            Xfood = REP.pos(leader_idx, :);

            if rand < 0.5
                X(i, :) = Xfood + CF * (X1 - X(i, :)) .* randn(1, nVar);
            else
                X(i, :) = Xfood + CF * (X2 - X(i, :)) .* randn(1, nVar);
            end
        end

        % Boundary processing
        X = boundaryCheck(X, var_min, var_max);

        % Update fitness
        for i = 1:Np
            fit(i, :) = fun(X(i, :));
        end

        % Archive update
        REP = updateRepository(REP, X, fit, ngrid, Nr);
        
        display(['Generation #' num2str(t) ' - Repository size: ' num2str(size(REP.pos, 1))]);
        % Update the iteration count and check termination criteria
        t = t + 1;
    end
end

% Population initialization function
function X = initialization(N, dim, ub, lb)
    X = rand(N, dim) .* (ub' - lb') + lb';
end

% Boundary processing function
function X = boundaryCheck(X, lb, ub)
    for i = 1:size(X, 1)
        FU = X(i, :) > ub';
        FL = X(i, :) < lb';
        X(i, :) = (X(i, :) .* ~(FU + FL)) + ub' .* FU + lb' .* FL;
    end
end

% Archive initialization function
function REP = initializeRepository(X, fit, ngrid)
    DOMINATED = checkDomination(fit);
    REP.pos = X(~DOMINATED, :);
    REP.pos_fit = fit(~DOMINATED, :);
    REP = updateGrid(REP, ngrid);
end

% Archive update function
function REP = updateRepository(REP, POS, POS_fit, ngrid, Nr)
    DOMINATED = checkDomination(POS_fit);
    REP.pos = [REP.pos; POS(~DOMINATED, :)];
    REP.pos_fit = [REP.pos_fit; POS_fit(~DOMINATED, :)];
    DOMINATED = checkDomination(REP.pos_fit);
    REP.pos_fit = REP.pos_fit(~DOMINATED, :);
    REP.pos = REP.pos(~DOMINATED, :);
    REP = updateGrid(REP, ngrid);
    
    % Obtain and process the first three non-dominant Pareto frontiers
    fronts = getThreeFronts(REP.pos, REP.pos_fit);
    if size(REP.pos, 1) > Nr
        REP = deleteFromFront(REP, size(REP.pos, 1) - Nr, ngrid, fronts);
    end
end

% Obtain the first three non-dominant Pareto frontiers
function fronts = getThreeFronts(pos, pos_fit)
    [fronts_all, ~] = fastNonDominatedSort(pos_fit);
    fronts = cell(3, 1);
    for i = 1:min(3, length(fronts_all))
        fronts{i} = fronts_all{i};
    end
end

% Fast non-dominated sorting algorithm
function [fronts, ranks] = fastNonDominatedSort(fit)
    N = size(fit, 1);
    S = cell(N, 1);
    n = zeros(N, 1);
    ranks = zeros(N, 1);
    fronts = {};
    F1 = [];
    for i = 1:N
        S{i} = [];
        n(i) = 0;
        for j = 1:N
            if dominates(fit(i, :), fit(j, :))
                S{i} = [S{i}; j];
            elseif dominates(fit(j, :), fit(i, :))
                n(i) = n(i) + 1;
            end
        end
        if n(i) == 0
            ranks(i) = 1;
            F1 = [F1; i];
        end
    end
    fronts{1} = F1;
    k = 1;
    while ~isempty(fronts{k})
        Q = [];
        for i = 1:length(fronts{k})
            p = fronts{k}(i);
            for j = 1:length(S{p})
                q = S{p}(j);
                n(q) = n(q) - 1;
                if n(q) == 0
                    ranks(q) = k + 1;
                    Q = [Q; q];
                end
            end
        end
        k = k + 1;
        fronts{k} = Q;
    end
end

% Delete the individuals in the specified frontier
function REP = deleteFromFront(REP, n_extra, ngrid, fronts)
    if ~isempty(fronts{3})
        target_front = fronts{3};
    elseif ~isempty(fronts{2})
        target_front = fronts{2};
    else
        target_front = fronts{1};
    end
    
    % Calculate the congestion distance
    crowding = zeros(length(target_front), 1);
    for m = 1:size(REP.pos_fit, 2)
        [m_fit, idx] = sort(REP.pos_fit(target_front, m), 'ascend');
        m_up = [m_fit(2:end); Inf];
        m_down = [Inf; m_fit(1:end-1)];
        distance = (m_up - m_down) / (max(m_fit) - min(m_fit));
        [~, idx] = sort(idx, 'ascend');
        crowding = crowding + distance(idx);
    end
    crowding(isnan(crowding)) = Inf;
    
    % Delete the individual with the smallest crowded distance
    [~, del_idx] = sort(crowding, 'ascend');
    del_idx = target_front(del_idx(1:n_extra));
    REP.pos(del_idx, :) = [];
    REP.pos_fit(del_idx, :) = [];
    REP = updateGrid(REP, ngrid);
end

% Check the dominance relationship function
function dom_vector = checkDomination(fitness)
    Np = size(fitness, 1);
    dom_vector = zeros(Np, 1);
    all_perm = nchoosek(1:Np, 2);
    all_perm = [all_perm; [all_perm(:, 2) all_perm(:, 1)]];
    d = dominates(fitness(all_perm(:, 1), :), fitness(all_perm(:, 2), :));
    dominated_particles = unique(all_perm(d == 1, 2));
    dom_vector(dominated_particles) = 1;
end

% Determine whether it dominates the function
function d = dominates(x, y)
    d = all(x <= y, 2) & any(x < y, 2);
end

% Update the grid function
function REP = updateGrid(REP, ngrid)
    ndim = size(REP.pos_fit, 2);
    REP.hypercube_limits = zeros(ngrid + 1, ndim);
    for dim = 1:ndim
        REP.hypercube_limits(:, dim) = linspace(min(REP.pos_fit(:, dim)), max(REP.pos_fit(:, dim)), ngrid + 1)';
    end

    npar = size(REP.pos_fit, 1);
    REP.grid_idx = zeros(npar, 1);
    REP.grid_subidx = zeros(npar, ndim);
    for n = 1:npar
        idnames = [];
        for d = 1:ndim
            REP.grid_subidx(n, d) = find(REP.pos_fit(n, d) <= REP.hypercube_limits(:, d)', 1, 'first') - 1;
            if REP.grid_subidx(n, d) == 0
                REP.grid_subidx(n, d) = 1;
            end
            idnames = [idnames ',' num2str(REP.grid_subidx(n, d))];
        end
        REP.grid_idx(n) = eval(['sub2ind(ngrid.*ones(1, ndim)' idnames ');']);
    end

    REP.quality = zeros(ngrid, 2);
    ids = unique(REP.grid_idx);
    for i = 1:length(ids)
        REP.quality(i, 1) = ids(i);
        REP.quality(i, 2) = 10 / sum(REP.grid_idx == ids(i));
    end
end

% Select the leader function
function selected = selectLeader(REP)
    total_quality = sum(REP.quality(:, 2));
    individual_probabilities = REP.quality(:, 2) / total_quality;
    
    % Calculate the cumulative probability
    cumulative_probabilities = cumsum(individual_probabilities);
    
    % Generate random numbers and select hypercubes
    rand_val = rand;
    sel_hyp = find(rand_val <= cumulative_probabilities, 1, 'first');
    
    % Select one solution from the selected hypercube as the leader
    idx = find(REP.grid_idx == REP.quality(sel_hyp, 1));
    selected = idx(randi(length(idx)));
end
